package com.eathemeat.trans.data

class DataManager {

    companion object {
        val sIntance = DataManager()
    }


}